# Doc-Form

Il s'agit d'une plateforme de partage documentaire

INSTALLATION</br>

 - Assurez-vous d'avoir NodeJS installé sur votre ordinateur</br>
 - Télécharger le zip ou cloner le projet sur votre ordinateur.</br>
 - Avec un terminal, rendez-vous dans le dossier de votre projet (cd ./path/to/your/project) et taper "npm install".</br>

FONCTIONS ACHEVEES</br>

-connexion / déconnexion (utilisation des jsonwebtoken)</br>
-Inscription utilisateur avec envoi du mot de pass généré par mail à l'utilisateur</br>
-Ajout de document en fonction du domaine du document</br>
-Téléchargement de fichier</br>
-Rechercher un document en fonction de sa description et de son titre</br>
-Suppression d'un document</br>


AMELIORATIONS POSSIBLES</br>

-gérer les extensions des fichiers envoyés</br>
-Limiter la taille des fichiers en fonctions de l'espace disponible</br>

